package military.interfaces;

public interface Private {
    double getSalary();
}
