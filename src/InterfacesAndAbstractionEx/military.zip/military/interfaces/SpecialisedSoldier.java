package military.interfaces;

import military.Corp;

public interface SpecialisedSoldier {
    Corp getCorp();
}
