package military.interfaces;

public interface Spy {
    String getCodeNumber();
}
