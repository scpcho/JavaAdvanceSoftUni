package foodShortage;

public interface Birthable {
    String getBirthDate();
}
