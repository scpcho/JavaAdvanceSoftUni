package defineInterfacePerson;


public interface Person {
    String getName();

    int getAge();
}