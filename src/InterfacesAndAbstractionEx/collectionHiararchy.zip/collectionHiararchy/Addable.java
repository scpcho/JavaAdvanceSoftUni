package collectionHiararchy;

public interface Addable {
    int add(String item);
}
