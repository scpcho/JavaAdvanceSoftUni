package src.javaOOP.WorkingWithAbastractionEx.cardSuit;

public enum Suits {

    CLUBS, DIAMONDS, HEARTS, SPADES

}