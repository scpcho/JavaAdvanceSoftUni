package vehicles;

public interface VehicleInterface {
    void drive(double distance);

    void refill(double quantity);
}