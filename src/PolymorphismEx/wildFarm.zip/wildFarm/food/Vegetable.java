package wildFarm.food;

import wildFarm.food.Food;

public class Vegetable extends Food {
    public Vegetable(int quantity) {
        super(quantity);
    }
}
