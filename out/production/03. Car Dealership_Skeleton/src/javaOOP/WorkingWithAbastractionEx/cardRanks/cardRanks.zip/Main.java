package src.javaOOP.WorkingWithAbastractionEx.cardRanks;

public class Main {
}
